import PlaygroundSupport
import Foundation
import UIKit

// 1. Перечисление для ошибок и их обработка

enum NetworkError: Error {
    case badRequest // 400
    case notFound // 404
    case internalServerError // 500
}

var currentError: NetworkError = .notFound // Пример ошибки

@MainActor func handleNetworkError() {
    do {
        throw currentError
    } catch let error as NetworkError { // Ловим error как NetworkError
        switch error {
        case .badRequest:
           print("Ошибка: Некорректный запрос (400)")
       case .notFound:
           print("Ошибка: Ресурс не найден (404)")
       case .internalServerError:
           print("Ошибка: Внутренняя ошибка сервера (500)")
       }
    } catch {
        print("Произошла неизвестная ошибка: \(error)") // Обрабатываем все другие возможные ошибки
    }
}

handleNetworkError() // Вызов функции для обработки ошибок

// 2. Проверка переменных в генерирующей функции

func generateData(value: Int?) throws -> Int {
    guard let value = value else {
        throw NetworkError.badRequest // Генерируем ошибку, если value nil
    }
    return value * 2
}

// Проверка

do {
    let result = try generateData(value: 10)
    print("Результат: \(result)") // Выведет 20
} catch NetworkError.badRequest {
    print("Ошибка: Переменная 'value' не задана")
}

do {
    let result = try generateData(value: nil)
    print("Результат: \(result)") // Не будет вызвано, тк будет ошибка
} catch NetworkError.badRequest {
    print("Ошибка: Переменная 'value' не задана") // Выведет сообщение об ошибке
}

// 3. Функция для проверки типов (без исключений), решил использовать Any

func checkTypes(value1: Any, value2: Any) {
    if type(of: value1) == type(of: value2) {
        print("Yes")
    } else {
        print("No")
    }
}

// Провекра

checkTypes(value1: true, value2: "false") // No
checkTypes(value1: [1, 5], value2: [8, 30]) // Yes

// 4. Функция для проверки типов (с исключениями)

enum TypeCheckError: Error {
    case typesMatch
    case typesMismatch
}

func checkTypesWithExceptions(value1: Any, value2: Any) throws {
    if type(of: value1) == type(of: value2) {
        throw TypeCheckError.typesMatch // Типы совпадают, выбрасываем исключение
    } else {
        throw TypeCheckError.typesMismatch // Типы не совпадают, выбрасываем другое исключение
    }
}

// Проверка

do {
    try checkTypesWithExceptions(value1: 7, value2: 45)
} catch TypeCheckError.typesMatch {
    print("Исключение: Типы совпадают!")
} catch TypeCheckError.typesMismatch {
    print("Исключение: Типы не совпадают!")
}

do {
    try checkTypesWithExceptions(value1: 85, value2: "Hi!")
} catch TypeCheckError.typesMatch {
    print("Исключение: Типы совпадают!")
} catch TypeCheckError.typesMismatch {
    print("Исключение: Типы не совпадают!")
}

// 5. Функция для сравнения значений

func compareValues<T: Equatable>(value1: T, value2: T) -> Bool {
    return value1 == value2
}

// Проверка

print(compareValues(value1: 1, value2: 1)) // true
print(compareValues(value1: 5, value2: 394867)) // false
print(compareValues(value1: "Hello", value2: "World!")) // false
print(compareValues(value1: "Hello, World!", value2: "Hello, World!")) // true
